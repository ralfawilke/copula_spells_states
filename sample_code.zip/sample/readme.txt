This folder contains data and STATA sample code for the paper "A Copula Duration Model with Dependent States and Spells".

data:

1.1. simdata.dta is the one of the simulated samples for Table 1.

estimation code:

2.1. estimation.do is the code for FMLE and PsMLE. The copula function is the Clayton copula (true model). The survival functions include Weibull proportional hazard (true model) and PWCON.

2.2. FMLE:

2.2.1. cccwph2s_v_reg_M1_the_s1.ado and cccwph2s_v_reg_M1_the_s2.ado are the maximum likelihood estimators for FMLE (31) and (32) respectively using Weibull model and the Clayton copula.

2.2.2. cccwph2s_v_reg_M1_the_s1_pwcon.ado and cccwph2s_v_reg_M1_the_s2_pwcon.ado are the maximum likelihood estimators for FMLE (31) and (32) respectively using PWCON model and the Clayton copula.

2.3. PsMLE:

2.3.1. wph2s_v_reg.ado and wph1s_v_reg_pwcon.ado are the maximum likelihood estimators for PsMLE first step (PMLE) using Weibull model and PWCON respectively.

2.3.2. cccwph2s_pl_M1_the_s1.ado and cccwph2s_pl_M1_the_s2.ado are the maximum likelihood estimators for PsMLE second step (31) and (32) respectively using the Clayton copula.
